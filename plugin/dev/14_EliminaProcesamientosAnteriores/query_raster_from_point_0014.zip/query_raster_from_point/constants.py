# -*- coding: utf-8 -*-

# general constants
APPLICATION_NAME = u'Query Raster From Point'
APPLICATION_VERSION = "0.14"

# output directory and filenames
STR_NAME_MEMORY_LAYER = "New memory layer"
STR_NEW_VRASTER_FIELDNAME = "v_raster"
