<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES" sourcelanguage="en_GB">
<context>
    <name>QueryRasterFromPoint</name>
    <message>
        <location filename="../query_raster_from_point.py" line="158"/>
        <source>&amp;Query raster from point</source>
        <translation>&amp;Consulta raster desde vector</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="148"/>
        <source>Query raster values from point vector layer</source>
        <translation>Consulta valores raster desde capa vectorial de puntos</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="192"/>
        <source>Select vector layer</source>
        <translation>Selecciones capa vectorial</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="200"/>
        <source>Select raster layer</source>
        <translation>Selecciones capa raster</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="210"/>
        <source>Select path output shapefile</source>
        <translation>Seleccione ruta del fichero shapefile de salida</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="236"/>
        <source>Vector layer and raster layer have different CRSs</source>
        <translation>Las capas vectorial y raster tienen diferente CRSs</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="300"/>
        <source>--- Select vector layer ---</source>
        <translation>--- Selecciones capa vectorial ---</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="311"/>
        <source>--- Select raster layer ---</source>
        <translation>--- Selecciones capa raster ---</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="320"/>
        <source>Open shapefile</source>
        <translation>Abrir shapefile</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="333"/>
        <source>Open raster</source>
        <translation>Abrir raster</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="349"/>
        <source>Processing completed successfully</source>
        <translation>Procesamiento completado satisfactoriamente</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point.py" line="372"/>
        <source>Search path output shapefile</source>
        <translation>Buscar ruta de shapefile de salida</translation>
    </message>
</context>
<context>
    <name>QueryRasterFromPointDialogBase</name>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="14"/>
        <source>Query raster from point</source>
        <translation>Consulta raster desde vector</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="20"/>
        <source>Input data</source>
        <translation>Datos de entrada</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="28"/>
        <source>Vector layer:</source>
        <translation>Capa vectorial:</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="189"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="58"/>
        <source>Raster layer:</source>
        <translation>Capa raster:</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="68"/>
        <source>Raster layers loaded in the QGIS Table Of Contents</source>
        <translation>Capas raster cargadas en la Tabla de Contenidos de QGIS</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="97"/>
        <source>Output layer</source>
        <translation>Capa de salida</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="105"/>
        <source>Memory layer</source>
        <translation>Capa en memoria</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="112"/>
        <source>Remove previous processings</source>
        <translation>Eliminar procesamientos anteriores</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="139"/>
        <source>Shapefile</source>
        <translation>Shapefile</translation>
    </message>
    <message>
        <location filename="../query_raster_from_point_dialog_base.ui" line="149"/>
        <source>Search path output shapefile...</source>
        <translation>Buscar ruta shapefile de salida...</translation>
    </message>
</context>
</TS>
